<template>
  <div class="min-h-screen bg-gray-50">
    <!-- Cabeçalho -->
    <header class="bg-cyan-600 text-white py-6 shadow-md">
      <div class="container mx-auto flex justify-between items-center px-6">
        <h1 class="text-3xl font-semibold">HospTech</h1>
        <nav class="space-x-6 text-lg font-medium">
          <a href="#" class="hover:text-cyan-200 transition-colors">Home</a>
          <a href="#" class="hover:text-cyan-200 transition-colors">Login</a>
          <a href="#" class="hover:text-cyan-200 transition-colors">Nossos Serviços</a>
          <a href="#" class="hover:text-cyan-200 transition-colors">Agendamento</a>
          <a href="#" class="hover:text-cyan-200 transition-colors">Chat</a>
          <a href="#" class="hover:text-cyan-200 transition-colors">Contato</a>
        </nav>
      </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container mx-auto p-8">
      <section class="bg-white rounded-lg shadow-lg p-8">
        <h2 class="text-3xl font-semibold text-cyan-600 mb-6 text-center">HospTech</h2>
        <p class="text-lg text-gray-700 leading-relaxed text-center">
          Apresentamos o projeto de Agendamento de Consultas Online, uma plataforma inovadora
          que facilita o acesso à saúde de forma rápida e prática. Nosso objetivo é eliminar as
          dificuldades do agendamento tradicional, permitindo que os usuários escolham data e
          horário com facilidade, visualizando a disponibilidade dos profissionais em tempo real.
          A plataforma envia lembretes automáticos, garantindo que os pacientes não esqueçam suas
          consultas. Para os profissionais de saúde, oferece uma gestão otimizada do tempo e
          redução de faltas, aumentando a satisfação do paciente. Com um design intuitivo e
          funcionalidades práticas, buscamos transformar a experiência de agendamento, tornando-a
          mais eficiente e acessível. Junte-se a nós nessa revolução no atendimento à saúde!
        </p>
      </section>
    </main>

    <!-- Rodapé (Footer) -->
    <footer class="bg-cyan-600 text-white text-center py-4 mt-8">
      <p class="text-sm">© 2025 HospTech. Todos os direitos reservados.</p>
    </footer>
  </div>
</template>

<script>
export default {
  name: 'HospTechApp'
}
</script>

<style scoped>
body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
</style>
